JUKE BOX
Michael Frans M. T. S. - 22711

- Nama aplikasi dibuat Jok Music
- Saat aplikasi awal dibuka akan menampilkan :
	* Jok Music dipaling atas
	* Dibawahnya ada button untuk ke about
	* Dibawah button tersebut ada Judul lagu, disini saya memilih lagu Tak Mungkin Bersama dari Judika
	* Dibawahnya judul ada nama artistnya yaitu Judika
	* Dibawah nama ada foto album judika
	* Dibawah foto tersebut ada lyric dari lagu tersebut
	* Dibawah lyric tersebut ada button yang berguna untuk play dan pause
- Saat awal dibuka, aplikasi ini tidak akan menampilkan animasi apa-apa, hanya menampilkan yang ada diatas
- Saat button about diklik akan pindah keactivity yang berisi about
- Pada lirik, kita bisa melihat keseluruhan isinya sebelum lagu dimulai. Saat lagu udah dimulai, kita tidak bisa melihat lirik yang sudah terlewat
- Jika kita mengscroll lirik pada saat lagu belum dimulai, maka akan otomatis kembali keatas saat button play ditekan. Ini juga sama terjadi jika kita mengscroll saat sedang dipause
- Button play akan berubah jadi pause jika lagu diplay, dan akan berubah jadi play saat tekan pause. Button pause juga akan jadi button play saat lagu sudah selesai diputar
- Saat lagunya sudah selesai diputar, maka lyric akan kembali ke yang paling atas dan bisa memutar lagunya lagi.

# Diakhir lagu ada jeda kosong karena disitu lagunya memang belum selesai, mohon maaf karena tidak memotongnya